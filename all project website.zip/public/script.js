// script.js

document.addEventListener('DOMContentLoaded', () => {
  const productList = document.getElementById('productList');
  const adminBtn = document.getElementById('adminBtn');
  const chatBtn = document.getElementById('chatBtn');

  // Modals
  const buyModal = document.getElementById('buyModal');
  const buyClose = document.getElementById('buyClose');
  const buyForm = document.getElementById('buyForm');
  const whatsappInput = document.getElementById('whatsappInput');
  const quantityInput = document.getElementById('quantityInput');
  const buyMessage = document.getElementById('buyMessage');

  const chatModal = document.getElementById('chatModal');
  const chatClose = document.getElementById('chatClose');
  const botSelect = document.getElementById('botSelect');
  const chatMessage = document.getElementById('chatMessage');
  const sendChatBtn = document.getElementById('sendChatBtn');
  const chatStatus = document.getElementById('chatStatus');

  // Admin login modal (simple prompt)
  async function adminLogin() {
    const username = prompt("Masukkan username admin:");
    if (username === null) return;
    const password = prompt("Masukkan password admin:");
    if (password === null) return;

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (data.success) {
        alert("Login berhasil! Mengalihkan ke panel admin...");
        window.location.href = '/admin.html';
      } else {
        alert("Login gagal: " + (data.message || "Username atau password salah"));
      }
    } catch (e) {
      alert("Terjadi kesalahan saat login");
    }
  }

  adminBtn.addEventListener('click', () => {
    adminLogin();
  });

  // Chat CS toggle modal
  chatBtn.addEventListener('click', () => {
    chatModal.style.display = 'block';
  });
  chatClose.addEventListener('click', () => {
    chatModal.style.display = 'none';
    chatMessage.value = '';
    chatStatus.textContent = '';
  });

  // Load products from backend
  async function loadProducts() {
    try {
      const res = await fetch('/api/products');
      const products = await res.json();
      productList.innerHTML = '';
      products.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
          <img src="${p.image}" alt="${p.name}" />
          <h3>${p.name}</h3>
          <p>Rp ${p.price.toLocaleString()}</p>
          <button class="buyBtn" data-id="${p.id}">Beli</button>
        `;
        productList.appendChild(card);
      });

      // Attach buy button event
      document.querySelectorAll('.buyBtn').forEach(btn => {
        btn.addEventListener('click', e => {
          const id = parseInt(e.target.dataset.id);
          openBuyModal(id);
        });
      });
    } catch (e) {
      productList.innerHTML = '<p>Gagal memuat produk.</p>';
    }
  }

  // Buy modal logic
  let currentProductId = null;
  function openBuyModal(productId) {
    currentProductId = productId;
    whatsappInput.value = '';
    quantityInput.value = 1;
    buyMessage.textContent = '';
    buyModal.style.display = 'block';
  }
  buyClose.addEventListener('click', () => {
    buyModal.style.display = 'none';
  });

  buyForm.addEventListener('submit', async e => {
    e.preventDefault();
    const whatsapp = whatsappInput.value.trim();
    const quantity = parseInt(quantityInput.value);
    if (!whatsapp) {
      buyMessage.textContent = 'Nomor WhatsApp harus diisi.';
      return;
    }
    if (quantity < 1) {
      buyMessage.textContent = 'Jumlah produk minimal 1.';
      return;
    }
    buyMessage.textContent = 'Mengirim pesanan...';

    try {
      const res = await fetch('/api/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          whatsapp,
          productId: currentProductId,
          quantity
        })
      });
      const data = await res.json();
      if (data.success) {
        buyMessage.textContent = 'Pesanan berhasil dikirim! CS akan menghubungi Anda.';
        setTimeout(() => {
          buyModal.style.display = 'none';
        }, 2000);
      } else {
        buyMessage.textContent = 'Gagal mengirim pesanan: ' + (data.error || '');
      }
    } catch (e) {
      buyMessage.textContent = 'Terjadi kesalahan saat mengirim pesanan.';
    }
  });

  // Chat CS send message
  sendChatBtn.addEventListener('click', async () => {
    const botIndex = parseInt(botSelect.value);
    const message = chatMessage.value.trim();
    if (!message) {
      chatStatus.textContent = 'Pesan tidak boleh kosong.';
      return;
    }
    chatStatus.textContent = 'Mengirim pesan...';

    try {
      const res = await fetch('/api/chatcs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ botIndex, message })
      });
      const data = await res.json();
      if (data.success) {
        chatStatus.textContent = 'Pesan berhasil dikirim.';
        chatMessage.value = '';
      } else {
        chatStatus.textContent = 'Gagal mengirim pesan: ' + (data.error || '');
      }
    } catch (e) {
      chatStatus.textContent = 'Terjadi kesalahan saat mengirim pesan.';
    }
  });

  // Close modals if click outside content
  window.addEventListener('click', e => {
    if (e.target === buyModal) buyModal.style.display = 'none';
    if (e.target === chatModal) chatModal.style.display = 'none';
  });

  // Load products on start
  loadProducts();
});